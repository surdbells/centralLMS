// reports/components/report-viewer/report-viewer.component.ts
// Full report viewer: chart + summary cards + data table + export

import { Component, OnInit, OnDestroy } from '@angular/core';
import {CommonModule, DatePipe, DecimalPipe} from '@angular/common';
import {ActivatedRoute, Router, RouterLink} from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { ReportService } from '../../services/report.service';
import { ReportResponse, ReportCatalogItem, ReportFilters } from '../../models/report.models';
import { ReportChartComponent } from '../report-chart/report-chart.component';
import { ReportTableComponent } from '../report-table/report-table.component';
import { ReportFiltersComponent } from '../report-filters/report-filters.component';
import { ReportExportComponent } from '../report-export/report-export.component';
import {AdmintopComponent} from '../../../partials/top/admintop/admintop.component';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-report-viewer',
  standalone: true,
  imports: [CommonModule, RouterLink, ReportChartComponent, ReportTableComponent, ReportFiltersComponent, ReportExportComponent, AdmintopComponent, FormsModule],
  providers: [
    { provide: DecimalPipe, useClass: DecimalPipe }
  ],
  template: `
    <app-admintop></app-admintop>
    <main class="main px-lg-6">
      <div class="container-fluid">
        <div class="report-viewer">
          <!-- Breadcrumb -->
          <nav class="mb-3">
            <ol class="breadcrumb small mb-0">
              <li class="breadcrumb-item"><a routerLink="/admin/reports">Reports</a></li>
              <li class="breadcrumb-item"><a routerLink="/admin/reports/catalog"
                                             [queryParams]="{category: reportItem?.category}">
                {{ formatKey(reportItem?.category || '') }}
              </a></li>
              <li class="breadcrumb-item active">{{ report?.report_name || reportItem?.name }}</li>
            </ol>
          </nav>

          <!-- Header -->
          <div class="d-flex justify-content-between align-items-start mb-4">
            <div>
              <h4 class="fw-bold mb-1">{{ report?.report_name || reportItem?.name || 'Loading...' }}</h4>
              <p class="text-muted mb-0 small">{{ report?.description || reportItem?.description }}</p>
            </div>
            <div class="d-flex gap-2">
              <app-report-export [reportKey]="reportKey" [filters]="currentFilters"
                                 *ngIf="reportItem?.exportable"></app-report-export>
              <button class="btn btn-sm btn-outline-primary" (click)="saveReport()" title="Save Report">
                <i class="bi bi-bookmark me-1"></i>Save
              </button>
              <button class="btn btn-sm btn-outline-secondary" (click)="refreshReport()" title="Refresh">
                <i class="bi bi-arrow-clockwise"></i>
              </button>
            </div>
          </div>

          <!-- ═══════ PARAMETER PICKER (learner/assessment/course) ═══════ -->
          <div class="card border-0 shadow-sm mb-4" *ngIf="paramPickerType">
            <div class="card-body">
              <div class="row g-3 align-items-end">
                <!-- Learner Picker -->
                <ng-container *ngIf="paramPickerType === 'learner'">
                  <div class="col-md-5">
                    <label class="form-label small fw-semibold">Search Learner</label>
                    <input type="text" class="form-control form-control-sm" placeholder="Type name or email..."
                           [(ngModel)]="pickerSearch" (input)="onPickerSearch()">
                  </div>
                  <div class="col-md-5" *ngIf="pickerOptions.length">
                    <label class="form-label small fw-semibold">Select Learner</label>
                    <select class="form-select form-select-sm" [(ngModel)]="pickerSelectedId" (change)="onPickerSelect()">
                      <option [ngValue]="null">Choose learner...</option>
                      <option *ngFor="let u of pickerOptions" [ngValue]="u.id || u.user_id">
                        {{ u.first_name || '' }} {{ u.last_name || '' }} ({{ u.email }})
                      </option>
                    </select>
                  </div>
                </ng-container>

                <!-- Assessment Picker -->
                <ng-container *ngIf="paramPickerType === 'assessment'">
                  <div class="col-md-8">
                    <label class="form-label small fw-semibold">Select Assessment</label>
                    <select class="form-select form-select-sm" [(ngModel)]="pickerSelectedId" (change)="onPickerSelect()">
                      <option [ngValue]="null">Choose assessment...</option>
                      <option *ngFor="let a of pickerOptions" [ngValue]="a.id || a.assessment_id">
                        {{ a.title || a.name }}
                      </option>
                    </select>
                  </div>
                </ng-container>

                <!-- Course Picker -->
                <ng-container *ngIf="paramPickerType === 'course'">
                  <div class="col-md-8">
                    <label class="form-label small fw-semibold">Select Course</label>
                    <select class="form-select form-select-sm" [(ngModel)]="pickerSelectedId" (change)="onPickerSelect()">
                      <option [ngValue]="null">Choose course...</option>
                      <option *ngFor="let c of pickerOptions" [ngValue]="c.id || c.course_id">
                        {{ c.title }}
                      </option>
                    </select>
                  </div>
                </ng-container>

                <div class="col-md-2">
                  <button class="btn btn-sm btn-primary w-100" (click)="loadReport()" [disabled]="!pickerSelectedId">
                    <i class="bi bi-play-fill me-1"></i>Run
                  </button>
                </div>
              </div>
            </div>
          </div>

          <!-- Standard Filters (non-picker reports) -->
          <app-report-filters *ngIf="!paramPickerType" [reportItem]="reportItem" [initialFilters]="currentFilters"
                              (filtersChanged)="onFiltersChanged($event)"></app-report-filters>

          <!-- Loading -->
          <div *ngIf="loading" class="text-center py-5">
            <div class="spinner-border text-primary" role="status"></div>
            <p class="mt-2 text-muted">Generating report...</p>
          </div>

          <!-- Error -->
          <div *ngIf="error" class="alert alert-danger">
            <i class="bi bi-exclamation-triangle me-2"></i>{{ error }}
            <button class="btn btn-sm btn-outline-danger ms-2" (click)="refreshReport()">Retry</button>
          </div>

          <!-- ═══════ REPORT CONTENT ═══════ -->
          <div *ngIf="report && !loading && !error">

            <!-- Summary Cards -->
            <div class="row g-3 mb-4" *ngIf="summaryCards.length">
              <div *ngFor="let card of summaryCards" class="col-sm-6 col-md-4 col-lg-3">
                <div class="card border-0 shadow-sm h-100">
                  <div class="card-body text-center py-3">
                    <p class="text-muted small mb-1">{{ card.label }}</p>
                    <h4 class="fw-bold mb-0" [class]="'text-' + card.color">{{ card.display }}</h4>
                  </div>
                </div>
              </div>
            </div>

            <!-- User Profile (Individual Reports) -->
            <div class="card border-0 shadow-sm mb-4" *ngIf="report.user">
              <div class="card-body">
                <h6 class="fw-semibold mb-3"><i class="bi bi-person-circle me-2"></i>Learner Profile</h6>
                <div class="row g-3">
                  <div class="col-md-3"><span class="text-muted small d-block">Name</span><strong>{{ report.user.full_name }}</strong></div>
                  <div class="col-md-3"><span class="text-muted small d-block">Email</span><strong>{{ report.user.email }}</strong></div>
                  <div class="col-md-3"><span class="text-muted small d-block">Department</span><strong>{{ report.user.department }}</strong></div>
                  <div class="col-md-3"><span class="text-muted small d-block">Job Title</span><strong>{{ report.user.job_title }}</strong></div>
                </div>
              </div>
            </div>

            <!-- Chart -->
            <div class="mb-4" *ngIf="chartData">
              <app-report-chart [data]="chartData" [chartType]="report.chart_type || 'bar'"
                                [reportKey]="reportKey" [allowTypeChange]="true"></app-report-chart>
            </div>

            <!-- Multi-section tables -->
            <ng-container *ngIf="sections.length">
              <div *ngFor="let section of sections" class="mb-4">
                <app-report-table [data]="section.data" [title]="section.title"
                                  [searchable]="true" [sortable]="true"></app-report-table>
              </div>
            </ng-container>

            <!-- Single data table -->
            <app-report-table *ngIf="!sections.length && tableData?.length"
                              [data]="tableData" [meta]="report.meta"
                              [title]="''" [searchable]="true" [sortable]="true"
                              (pageChange)="onPageChange($event)"></app-report-table>

            <!-- Badges -->
            <div class="card border-0 shadow-sm mb-4" *ngIf="report.badges?.length">
              <div class="card-body">
                <h6 class="fw-semibold mb-3"><i class="bi bi-award me-2"></i>Badges ({{ report.badges.length }})</h6>
                <div class="d-flex flex-wrap gap-2">
              <span *ngFor="let b of report.badges" class="badge bg-warning-subtle text-warning px-3 py-2" style="font-size:.8rem">
                <i class="bi bi-award me-1"></i>{{ b.badge_name }}
              </span>
                </div>
              </div>
            </div>

            <!-- Certificates -->
            <div class="card border-0 shadow-sm mb-4" *ngIf="report.certificates?.length">
              <div class="card-body">
                <h6 class="fw-semibold mb-3"><i class="bi bi-patch-check me-2"></i>Certificates</h6>
                <app-report-table [data]="report.certificates" [title]="''" [sortable]="true"></app-report-table>
              </div>
            </div>

            <!-- Risk Breakdown (Compliance Executive) -->
            <div class="card border-0 shadow-sm mb-4" *ngIf="report.risk_breakdown">
              <div class="card-body">
                <h6 class="fw-semibold mb-3"><i class="bi bi-shield-exclamation me-2"></i>Risk Breakdown</h6>
                <div class="d-flex gap-3">
                  <span class="badge bg-danger px-3 py-2">Critical: {{ report.risk_breakdown.critical }}</span>
                  <span class="badge bg-warning px-3 py-2">High: {{ report.risk_breakdown.high }}</span>
                  <span class="badge bg-info px-3 py-2">Medium: {{ report.risk_breakdown.medium }}</span>
                  <span class="badge bg-secondary px-3 py-2">Low: {{ report.risk_breakdown.low }}</span>
                </div>
              </div>
            </div>

            <!-- Empty state -->
            <div *ngIf="!sections.length && !tableData?.length && !report.user && !summaryCards.length"
                 class="text-center py-5 text-muted">
              <i class="bi bi-inbox fs-1 d-block mb-2"></i>
              <p>No data available for the selected filters.</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  `
})
export class ReportViewerComponent implements OnInit, OnDestroy {
  reportKey = '';
  reportItem?: ReportCatalogItem;
  report: any = null;
  currentFilters: ReportFilters = {};
  summaryCards: SummaryCard[] = [];
  loading = false;
  error = '';
  private destroy$ = new Subject<void>();

  // Data routing
  chartData: any = null;
  tableData: any[] = [];
  sections: { title: string; data: any[] }[] = [];

  // Parameter picker
  paramPickerType: 'learner' | 'assessment' | 'course' | null = null;
  pickerSearch = '';
  pickerOptions: any[] = [];
  pickerSelectedId: number | null = null;
  private searchSubject = new Subject<string>();

  private individualReports = ['individual_progress_report', 'individual_assessment_report', 'learner_transcript'];
  private assessmentReports = ['question_analysis_report', 'assessment_item_analysis'];
  private courseReports = ['course_learner_roster'];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private reportService: ReportService,
    private dp: DecimalPipe
  ) {}

  ngOnInit(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      this.reportKey = params['key'] || '';
      this.detectPickerType();
      this.loadCatalogItem();
      if (!this.paramPickerType) {
        this.loadReport();
      }
    });

    // Debounced learner search
    this.searchSubject.pipe(
      debounceTime(300), distinctUntilChanged(), takeUntil(this.destroy$)
    ).subscribe(term => {
      if (term.length >= 2) {
        this.reportService.getLearners(term).subscribe(users => this.pickerOptions = users);
      }
    });
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }

  private detectPickerType(): void {
    if (this.individualReports.includes(this.reportKey)) {
      this.paramPickerType = 'learner';
    } else if (this.assessmentReports.includes(this.reportKey)) {
      this.paramPickerType = 'assessment';
      this.reportService.getAssessments().subscribe(a => this.pickerOptions = a);
    } else if (this.courseReports.includes(this.reportKey)) {
      this.paramPickerType = 'course';
      this.reportService.getCourses().subscribe(c => this.pickerOptions = c);
    } else {
      this.paramPickerType = null;
    }
  }

  onPickerSearch(): void { this.searchSubject.next(this.pickerSearch); }

  onPickerSelect(): void {
    if (!this.pickerSelectedId) return;
    if (this.paramPickerType === 'learner') {
      this.currentFilters = { ...this.currentFilters, learner_id: this.pickerSelectedId };
    } else if (this.paramPickerType === 'assessment') {
      this.currentFilters = { ...this.currentFilters, assessment_id: this.pickerSelectedId };
    } else if (this.paramPickerType === 'course') {
      this.currentFilters = { ...this.currentFilters, course_id: this.pickerSelectedId };
    }
  }

  onFiltersChanged(filters: ReportFilters): void {
    this.currentFilters = filters;
    this.loadReport();
  }

  onPageChange(page: number): void {
    this.currentFilters = { ...this.currentFilters, page };
    this.loadReport();
  }

  refreshReport(): void { this.loadReport(); }

  saveReport(): void {
    const name = prompt('Save report as:', this.report?.report_name || this.reportKey);
    if (!name) return;
    this.reportService.saveReport(name, this.reportKey, this.currentFilters).subscribe({
      next: () => alert('Report saved successfully!'),
      error: () => alert('Failed to save report.')
    });
  }

  private loadCatalogItem(): void {
    this.reportService.getCatalog().subscribe(items => {
      this.reportItem = items.find(i => i.key === this.reportKey);
    });
  }

  loadReport(): void {
    if (!this.reportKey) return;
    if (this.paramPickerType && !this.pickerSelectedId) return;

    this.loading = true;
    this.error = '';
    this.sections = [];
    this.chartData = null;
    this.tableData = [];
    this.report = null;

    this.reportService.runReport(this.reportKey, this.currentFilters).pipe(
      takeUntil(this.destroy$)
    ).subscribe({
      next: (res: any) => {
        this.report = res;
        this.processReport(res);
        this.loading = false;
      },
      error: (err) => {
        this.error = err?.error?.message || err?.message || 'Failed to load report.';
        this.loading = false;
      }
    });
  }

  /** Detect report structure and route data to chart/table/sections */
  private processReport(res: any): void {
    // Extract summary
    this.summaryCards = this.extractSummary(res.summary || res.org_summary);

    // CASE 1: Standard .data array
    if (res.data && Array.isArray(res.data) && res.data.length) {
      this.tableData = res.data;
      this.chartData = res;
      return;
    }

    // CASE 2: Individual Progress (courses array)
    if (res.courses && Array.isArray(res.courses)) {
      this.tableData = res.courses;
      if (res.courses.length) this.chartData = { data: res.courses };
      return;
    }

    // CASE 3: Multi-section reports
    const sectionMap = [
      { key: 'by_branch', title: 'By Branch' },
      { key: 'by_department', title: 'By Department' },
      { key: 'by_team', title: 'By Team' },
      { key: 'by_course', title: 'By Course' },
      { key: 'non_compliant_learners', title: 'Non-Compliant Learners' },
      { key: 'trends', title: 'Trends' },
      { key: 'monthly_trend', title: 'Monthly Trend' },
      { key: 'by_hour', title: 'By Hour' },
      { key: 'by_day', title: 'By Day' },
      { key: 'by_activity', title: 'By Activity' },
    ];

    for (const s of sectionMap) {
      if (res[s.key] && Array.isArray(res[s.key]) && res[s.key].length) {
        this.sections.push({ title: s.title, data: res[s.key] });
      }
    }

    if (this.sections.length) {
      this.chartData = res;  // Chart can extract from by_branch, by_department etc.
      return;
    }

    // CASE 4: Find any array in the response
    for (const [k, v] of Object.entries(res)) {
      if (Array.isArray(v) && (v as any[]).length && typeof (v as any[])[0] === 'object' &&
        !['badges', 'certificates', 'applied_filters'].includes(k)) {
        this.tableData = v as any[];
        this.chartData = { data: this.tableData };
        break;
      }
    }
  }

  private extractSummary(summary?: Record<string, any>): SummaryCard[] {
    if (!summary) return [];
    const cards: SummaryCard[] = [];
    const colorMap: Record<string, string> = {
      total: 'primary', rate: 'success', overdue: 'danger', pending: 'warning',
      active: 'info', avg: 'primary', score: 'success', compliance: 'success',
      completed: 'success', not_started: 'secondary', in_progress: 'warning',
      certificates: 'info', badges: 'warning', points: 'primary', time: 'info',
      mandatory: 'danger', non_compliant: 'danger'
    };

    for (const [key, value] of Object.entries(summary)) {
      if (value == null || typeof value === 'object' || key === 'data_source' || key === 'breakdown') continue;
      const label = this.formatKey(key);
      let color = 'primary';
      for (const [hint, c] of Object.entries(colorMap)) {
        if (key.toLowerCase().includes(hint)) { color = c; break; }
      }
      const display = typeof value === 'number'
        ? (key.includes('rate') ? this.dp.transform(value, '1.0-1')! + '%' :
          (value % 1 !== 0 ? this.dp.transform(value, '1.0-1')! : this.dp.transform(value, '1.0-0')!))
        : String(value);
      cards.push({ label, display, color });
    }
    return cards.slice(0, 10);
  }

  formatKey(k: string): string {
    return k.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  }
}

interface SummaryCard { label: string; display: string; color: string; }
